/**
 * AWS Lambda Backend Handler for Ganitha Deepthi Books Distribution & Audit Management System.
 * Runtime: Node.js 18+ or 20+
 * Environment Variables Required:
 * - TABLE_NAME: GanithaDeepthiTable (DynamoDB table with Partition Key "pk" [String] and Sort Key "sk" [String])
 * - RECEIPTS_BUCKET_NAME: ganitha-deepthi-receipts-bucket (S3 bucket for upload storage)
 */

const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, ScanCommand, PutCommand, DeleteCommand, BatchWriteCommand } = require("@aws-sdk/lib-dynamodb");
const { S3Client, PutObjectCommand } = require("@aws-sdk/client-s3");
const { getSignedUrl } = require("@aws-sdk/s3-request-presigner");

const ddbClient = new DynamoDBClient({});
const db = DynamoDBDocumentClient.from(ddbClient);
const s3 = new S3Client({});

const TABLE_NAME = process.env.TABLE_NAME || "GanithaDeepthiTable";
const BUCKET_NAME = process.env.RECEIPTS_BUCKET_NAME || "ganitha-deepthi-receipts-bucket";

// Default credentials to seed the DB on first run if empty
const defaultDistributorCredentials = [{ "username": "apmf_distributor", "password": "APMF@DIST2026" }];
const defaultCredentials = [
  { "district": "Alluri Sitharama Raju", "username": "apmf_asr", "password": "APMF@ASR2026" },
  { "district": "Anakapalli", "username": "apmf_aka", "password": "APMF@AKA2026" },
  { "district": "Ananthapuramu", "username": "apmf_atp", "password": "APMF@ATP2026" },
  { "district": "Annamayya", "username": "apmf_ann", "password": "APMF@ANN2026" },
  { "district": "Bapatla", "username": "apmf_bap", "password": "APMF@BAP2026" },
  { "district": "Chittoor", "username": "apmf_chi", "password": "APMF@CHI2026" },
  { "district": "Dr. B. R. Ambedkar Konaseema", "username": "apmf_kon", "password": "APMF@KON2026" },
  { "district": "East Godavari", "username": "apmf_egd", "password": "APMF@EGD2026" },
  { "district": "Eluru", "username": "apmf_elu", "password": "APMF@ELU2026" },
  { "district": "Guntur", "username": "apmf_gnt", "password": "APMF@GNT2026" },
  { "district": "Kakinada", "username": "apmf_kak", "password": "APMF@KAK2026" },
  { "district": "Krishna", "username": "apmf_kri", "password": "APMF@KRI2026" },
  { "district": "Kurnool", "username": "apmf_kur", "password": "APMF@KUR2026" },
  { "district": "Markapuram", "username": "apmf_mar", "password": "APMF@MAR2026" },
  { "district": "Nandyal", "username": "apmf_nan", "password": "APMF@NAN2026" },
  { "district": "NTR", "username": "apmf_ntr", "password": "APMF@NTR2026" },
  { "district": "Palnadu", "username": "apmf_pal", "password": "APMF@PAL2026" },
  { "district": "Parvathipuram Manyam", "username": "apmf_pmn", "password": "APMF@PMN2026" },
  { "district": "Polavaram", "username": "apmf_pol", "password": "APMF@POL2026" },
  { "district": "Prakasam", "username": "apmf_pra", "password": "APMF@PRA2026" },
  { "district": "Sri Potti Sriramulu Nellore", "username": "apmf_nel", "password": "APMF@NEL2026" },
  { "district": "Srikakulam", "username": "apmf_skm", "password": "APMF@SKM2026" },
  { "district": "Sri Sathya Sai", "username": "apmf_sss", "password": "APMF@SSS2026" },
  { "district": "Tirupati", "username": "apmf_tpt", "password": "APMF@TPT2026" },
  { "district": "Visakhapatnam", "username": "apmf_vsp", "password": "APMF@VSP2026" },
  { "district": "Vizianagaram", "username": "apmf_vzm", "password": "APMF@VZM2026" },
  { "district": "West Godavari", "username": "apmf_wgd", "password": "APMF@WGD2026" },
  { "district": "YSR Kadapa", "username": "apmf_kdp", "password": "APMF@KDP2026" },
  { "district": "VGS books", "username": "vgs_books", "password": "VGS@BOOKS2026" },
  { "district": "APMF amount", "username": "apmf_amount", "password": "APMF@AMT2026" }
];

exports.handler = async (event) => {
  // Common CORS headers
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "OPTIONS,GET,POST"
  };

  const method = event.requestContext?.http?.method || event.httpMethod;
  if (method === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  try {
    const path = event.rawPath || event.path;
    const body = event.body ? JSON.parse(event.body) : {};

    // 1. GET ALL DATA
    if (path === "/data" && method === "GET") {
      const data = await scanAllData();

      // Database Seeding: If no credentials exist in DynamoDB, seed default credentials
      if (!data.credentials.length) {
        await seedDatabase();
        const freshData = await scanAllData();
        return { statusCode: 200, headers, body: JSON.stringify(freshData) };
      }

      return { statusCode: 200, headers, body: JSON.stringify(data) };
    }

    // 2. SAVE OR UPDATE ITEM
    if (path === "/save" && method === "POST") {
      const { type, item } = body;
      if (!type || !item || !item.id) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing type, item or item.id" }) };
      }
      
      await db.send(new PutCommand({
        TableName: TABLE_NAME,
        Item: {
          pk: type,
          sk: item.id,
          ...item
        }
      }));
      return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
    }

    // 3. DELETE ITEM
    if (path === "/delete" && method === "POST") {
      const { type, id } = body;
      if (!type || !id) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing type or id" }) };
      }
      await db.send(new DeleteCommand({
        TableName: TABLE_NAME,
        Key: {
          pk: type,
          sk: id
        }
      }));
      return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
    }

    // 4. PRESIGN S3 RECEIPT UPLOAD URL
    if (path === "/presign-receipt" && method === "POST") {
      const { fileName, fileType, district } = body;
      if (!fileName || !fileType) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Missing fileName or fileType" }) };
      }

      const fileExtension = fileName.substring(fileName.lastIndexOf("."));
      const uniqueFileName = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}${fileExtension}`;
      const districtFolder = district ? `${district.replace(/[^a-zA-Z0-9]/g, "_")}/` : "";
      const s3Key = `receipts/${districtFolder}${uniqueFileName}`;

      const s3Command = new PutObjectCommand({
        Bucket: BUCKET_NAME,
        Key: s3Key,
        ContentType: fileType
      });

      const uploadUrl = await getSignedUrl(s3, s3Command, { expiresIn: 3600 });
      const fileUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/${s3Key}`;

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ uploadUrl, fileUrl })
      };
    }

    // 5. RESET TRANSACTIONAL DATA (keeps credentials)
    if (path === "/reset" && method === "POST") {
      const items = await scanAllDataRaw();
      const transactionTypes = ["entry", "payment", "receipt", "centre", "requirement", "audit", "distributorStatus"];
      const toDelete = items.filter(x => transactionTypes.includes(x.pk));

      // Batch delete in chunks of 25 (DynamoDB limit)
      for (let i = 0; i < toDelete.length; i += 25) {
        const chunk = toDelete.slice(i, i + 25);
        const writeRequests = chunk.map(x => ({
          DeleteRequest: {
            Key: { pk: x.pk, sk: x.sk }
          }
        }));
        await db.send(new BatchWriteCommand({
          RequestItems: {
            [TABLE_NAME]: writeRequests
          }
        }));
      }

      return { statusCode: 200, headers, body: JSON.stringify({ success: true }) };
    }

    return { statusCode: 404, headers, body: JSON.stringify({ error: "Not Found" }) };

  } catch (err) {
    console.error("Lambda Handler Error:", err);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: err.message || "Internal Server Error",
        stack: err.stack ? err.stack.toString() : "No stack trace available",
        raw: JSON.stringify(err, Object.getOwnPropertyNames(err))
      })
    };
  }
};

// Helper to Scan DynamoDB
async function scanAllDataRaw() {
  let items = [];
  let lastEvaluatedKey = undefined;
  do {
    const params = { TableName: TABLE_NAME };
    if (lastEvaluatedKey) {
      params.ExclusiveStartKey = lastEvaluatedKey;
    }
    const response = await db.send(new ScanCommand(params));
    items.push(...(response.Items || []));
    lastEvaluatedKey = response.LastEvaluatedKey;
  } while (lastEvaluatedKey);
  return items;
}

async function scanAllData() {
  const items = await scanAllDataRaw();
  const data = {
    entries: [],
    payments: [],
    receipts: [],
    receptionCentres: [],
    bookRequirements: [],
    audit: [],
    distributorStatus: [],
    credentials: [],
    distributorCredentials: []
  };

  items.forEach(item => {
    const cleanItem = { ...item };
    delete cleanItem.pk;
    delete cleanItem.sk;

    if (item.pk === "entry") data.entries.push(cleanItem);
    else if (item.pk === "payment") data.payments.push(cleanItem);
    else if (item.pk === "receipt") data.receipts.push(cleanItem);
    else if (item.pk === "centre") data.receptionCentres.push(cleanItem);
    else if (item.pk === "requirement") data.bookRequirements.push(cleanItem);
    else if (item.pk === "audit") data.audit.push(cleanItem);
    else if (item.pk === "distributorStatus") data.distributorStatus.push(cleanItem);
    else if (item.pk === "credential") data.credentials.push(cleanItem);
    else if (item.pk === "distributorCredential") data.distributorCredentials.push(cleanItem);
  });

  return data;
}

// Database Seeding helper
async function seedDatabase() {
  console.log("Seeding credentials into DynamoDB...");
  const putPromises = [];

  // Seed credentials
  defaultCredentials.forEach(cred => {
    const id = cred.username;
    putPromises.push(db.send(new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        pk: "credential",
        sk: id,
        ...cred
      }
    })));
  });

  // Seed distributor credentials
  defaultDistributorCredentials.forEach(dcred => {
    const id = dcred.username;
    putPromises.push(db.send(new PutCommand({
      TableName: TABLE_NAME,
      Item: {
        pk: "distributorCredential",
        sk: id,
        ...dcred
      }
    })));
  });

  await Promise.all(putPromises);
  console.log("Database seeded successfully.");
}
